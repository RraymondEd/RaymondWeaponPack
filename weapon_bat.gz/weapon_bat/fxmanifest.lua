fx_version 'cerulean'
game 'gta5'

author 'Raymond'
description 'Bat'
version '1.0.0'

files {
    'stream/*.ydr'
}

