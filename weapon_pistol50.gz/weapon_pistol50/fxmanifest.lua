fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'Desert Eagle'
version '1.0.0'

files {
    'stream/*.ytd',
    'stream/*.ydr'
}


