fx_version 'cerulean'
game 'gta5'

author 'Raymond'
description 'Glacier Rifle'
version '1.0.0'

files {
    'stream/*.ytd'
}

